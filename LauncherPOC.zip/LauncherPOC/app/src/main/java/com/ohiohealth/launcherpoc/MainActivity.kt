package com.ohiohealth.launcherpoc

import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // todo: create a list of applications that can be launched
        // Create a method to place them all on the screen in an organized fashion

        CreateButtons()

    }

    public fun CreateButtons()
    {
        val constraintLayout = findViewById<ConstraintLayout>(R.id.main_id)
        val button = Button(this)
        button.layoutParams = ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT)
        button.tag = "com.netflix.mediaclient"
        val intent = packageManager.getLaunchIntentForPackage(button.tag as String)
        val banner = intent?.let { packageManager.getActivityIcon(it) }
        button.setOnClickListener(View.OnClickListener {
            onLaunchBtnClick(button)
        })
        button.background = banner;
        constraintLayout.addView(button);
    }

    public fun onLaunchBtnClick(v: View): Unit {
        val tag = v.tag as String;
        val launchIntent = packageManager.getLaunchIntentForPackage(tag)
        startActivity(launchIntent)
    }

    public fun onLaunchBtnClickOLd(v: View): Unit {
        try {


            val tag = v.tag as String;
            val launchIntent = packageManager.getLaunchIntentForPackage(tag)
            //launchIntent = packageManager.getLeanbackLaunchIntentForPackage(tag)


            val packages = packageManager.getInstalledPackages(0)
            //val pac = packages.find { x -> tag == x.packageName }

            val pac = packageManager.getPackageInfo("com.netflix.mediaclient", 0)

            val btnIntent = Intent(Intent.ACTION_VIEW)

            btnIntent.setClassName("com.netflix.mediaclient", "com.netflix.mediaclient.ui.launch.UIWebViewActivity");


            val intent = Intent()
            intent.component = ComponentName("com.netflix.mediaclient", "com.netflix.mediaclient.ui.launch.UIWebViewActivity")
            val resolveInfo = packageManager.resolveActivity(intent, 0)

            val icon = resolveInfo!!.loadIcon(packageManager)


            v.background = icon


            startActivity(btnIntent)

        }
        catch(e :Exception)
        {
            Toast.makeText(this, e.message, Toast.LENGTH_LONG).show();

        }
    }

    public fun onMapsClick(v: View): Unit {
        // Create a Uri from an intent string. Use the result to create an Intent.
        val gmmIntentUri = Uri.parse("google.streetview:cbll=46.414382,10.013988")

        // Create an Intent from gmmIntentUri. Set the action to ACTION_VIEW
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
        // Make the Intent explicit by setting the Google Maps package
        mapIntent.setPackage("com.google.android.apps.maps")

        // Attempt to start an activity that can handle the Intent
        startActivity(mapIntent)
    }
}